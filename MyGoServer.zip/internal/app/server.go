package app

import (
	"context"
	"errors"
	"fmt"
	"log"
	"my-go-server/internal/config"
	deliveryhttp "my-go-server/internal/delivery/http"
	"my-go-server/internal/delivery/http/handler"
	"my-go-server/internal/repository"
	database "my-go-server/internal/repository/db"
	"my-go-server/internal/usecase"
	"net/http"
	"os/signal"
	"syscall"
	"time"

	"github.com/joho/godotenv"
)

func Run() {
	if err := godotenv.Load(); err != nil {
		log.Fatalf("error loading env variables: %s", err.Error())
	}

	cfg, err := config.New()

	if err != nil {
		log.Fatalf("failed to load config: %s", err.Error())
	}

	postgresDB, err := database.NewPostgresDB(cfg.DB)
	if err != nil {
		log.Fatalf("failed to initialize db: %s", err.Error())
	}
	defer postgresDB.Close()

	dbrepo := database.NewDBRepository(postgresDB)
	repo := repository.NewRepository(dbrepo)
	uc := usecase.NewService(repo)
	h := handler.NewHandler(uc)
	 

	srv := http.Server{
		Addr: ":"+cfg.Server.Port,
		Handler: deliveryhttp.SetupRoutes(h),
	}


	go func() {
		fmt.Printf("Listening on :%s\n", cfg.Server.Port)
		
		if err := srv.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
			log.Fatalf("server error: %s", err.Error())
		}
	} ()
	

	shutdown, stop := signal.NotifyContext(context.Background(), syscall.SIGTERM, syscall.SIGINT)
	defer stop()
	<-shutdown.Done()

	fmt.Println("Shutting down server...")
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	if err := srv.Shutdown(ctx); err != nil {
		fmt.Printf("Shutdown with error: %v", err)
		return
	}
	fmt.Printf("Shutdown complete.")

}